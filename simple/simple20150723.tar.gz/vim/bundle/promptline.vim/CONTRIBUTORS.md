[Henrique Ferreiro](https://github.com/hferreiro) - fix tilde expansion in bash 4.3

[Peter Fern](https://github.com/pdf) - Add `only_if_ssh` to host function
